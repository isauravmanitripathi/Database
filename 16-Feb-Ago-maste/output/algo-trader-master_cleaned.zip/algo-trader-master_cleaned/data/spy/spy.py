from data.spy.tickers import SpyTickers
if __name__ == '__main__':
    spyTickers = SpyTickers()
